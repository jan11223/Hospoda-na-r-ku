SAMOSTATNE HTML SOUBORY – HOSPODA NA RUZKU

Kazda HTML stranka obsahuje vlastni CSS, JavaScript i obrazky, takze je technicky samostatna. Pro funkcni proklikavani webu nahraj vsechny HTML soubory do stejne slozky na GitHub Pages. Zacni souborem index.html.

Soubory: index.html, jidelnicek.html, objednavka.html, informace.html, onas.html, kontakt.html.
Poznamka: objednavky a kontaktni formular jsou zatim pouze ukazkove a nic realne neodesilaji.
